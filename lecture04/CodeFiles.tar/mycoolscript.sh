# This is a better scrip
# Done using different approaches
# This script is not going to work
# This scrip is not good
